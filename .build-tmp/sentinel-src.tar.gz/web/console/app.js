/* app.js — UI wiring: map, camera list, live feed, alerts, stats.
 *
 * All data comes from window.SentinelAPI (api.js). This file knows nothing about
 * whether that data is real or demo — it just renders whatever arrives, and
 * shows the DEMO/LIVE badge that api.js reports.
 *
 * No inline event handlers anywhere (the console's CSP is script-src 'self'
 * with no 'unsafe-inline', so an onclick="" attribute would silently do
 * nothing) — everything is wired with addEventListener.
 */
(function () {
  "use strict";

  // ---------------------------------------------------------------------
  // A flat-earth projection for a small area, so the map works with no
  // basemap tiles at all (the console's CSP is img-src 'self', which rules
  // out fetching tiles from any real map provider — see web/nginx.conf).
  // Leaflet's CRS.Simple treats coordinates as a plain (y, x) plane, so this
  // just needs *a* consistent, roughly-metric mapping from lat/lon to it.
  // ---------------------------------------------------------------------

  const REF_LAT = 23.02;
  const REF_LON = 72.55;
  const UNITS_PER_DEGREE = 100000;
  const METRES_PER_DEGREE_LAT = 111320;
  const UNITS_PER_METRE = UNITS_PER_DEGREE / METRES_PER_DEGREE_LAT;
  const LON_SCALE = Math.cos((REF_LAT * Math.PI) / 180);

  function toPlane(lat, lon) {
    const y = (lat - REF_LAT) * UNITS_PER_DEGREE;
    const x = (lon - REF_LON) * UNITS_PER_DEGREE * LON_SCALE;
    return L.latLng(y, x);
  }

  function sectorPolygon(centre, bearingDeg, fovDeg, rangeM) {
    if (bearingDeg == null || fovDeg == null || !rangeM) return null;
    const r = rangeM * UNITS_PER_METRE;
    const points = [centre];
    const start = bearingDeg - fovDeg / 2;
    const steps = Math.max(2, Math.round(fovDeg / 8));
    for (let i = 0; i <= steps; i++) {
      const angle = ((start + (fovDeg * i) / steps) * Math.PI) / 180;
      points.push(L.latLng(centre.lat + r * Math.cos(angle), centre.lng + r * Math.sin(angle)));
    }
    points.push(centre);
    return points;
  }

  // ---------------------------------------------------------------------
  // Status → colour
  // ---------------------------------------------------------------------

  const STATUS_COLOR = {
    active: "#35d0ba",
    faulty: "#ef5a6f",
    maintenance: "#f0a63c",
    inactive: "#4a5568",
    decommissioned: "#4a5568",
    planned: "#4a5568",
  };
  function statusColor(status) { return STATUS_COLOR[status] || STATUS_COLOR.inactive; }

  const ALERT_KINDS = new Set(["dwell", "abandoned", "proximity", "stream_gap"]);
  const INFO_KINDS = new Set(["anpr", "scene_change"]);
  function severityOf(kind) {
    if (ALERT_KINDS.has(kind)) return "alert";
    if (INFO_KINDS.has(kind)) return "info";
    return "routine";
  }

  // ---------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------

  let cameras = [];
  let markers = new Map(); // camera_id -> {marker, wedge}
  let selectedCameraId = null;
  let statusFilter = "all";
  let searchTerm = "";
  const liveTracks = new Set();
  let openAlerts = 0;

  let map;

  // ---------------------------------------------------------------------
  // Boot
  // ---------------------------------------------------------------------

  document.addEventListener("DOMContentLoaded", async () => {
    initMap();
    initClock();
    wireSidebarControls();
    wireTabs();
    wireDrawer();

    cameras = await window.SentinelAPI.fetchCameras();
    renderCameraList();
    plotCameras();
    updateDataModeBadge();
    updateStats();

    window.SentinelAPI.connectEvents(cameras, handleEvent);
    // The event source may take a moment to decide real-vs-demo; reflect that
    // once it has.
    setTimeout(updateDataModeBadge, 2700);
  });

  function initMap() {
    map = L.map("map", {
      crs: L.CRS.Simple,
      zoomControl: true,
      attributionControl: false,
      minZoom: -3,
      maxZoom: 6,
    });
    map.setView([0, 0], 2);
  }

  function initClock() {
    const el = document.getElementById("clock");
    const tick = () => { el.textContent = new Date().toLocaleTimeString("en-GB"); };
    tick();
    setInterval(tick, 1000);
  }

  function updateDataModeBadge() {
    const badge = document.getElementById("data-mode");
    if (window.SentinelAPI.usingDemoData) {
      badge.textContent = "DEMO DATA";
      badge.className = "badge badge-demo";
      badge.title = "No live registry/analytics endpoint reachable — showing bundled demo cameras and a synthetic event feed shaped like the real one.";
    } else {
      badge.textContent = "LIVE";
      badge.className = "badge badge-live";
      badge.title = "Connected to the registry API.";
    }
  }

  // ---------------------------------------------------------------------
  // Camera list + filters
  // ---------------------------------------------------------------------

  function wireSidebarControls() {
    document.getElementById("camera-search").addEventListener("input", (e) => {
      searchTerm = e.target.value.trim().toLowerCase();
      renderCameraList();
    });

    const chips = document.querySelectorAll("#status-filters .chip");
    chips.forEach((chip) => {
      chip.addEventListener("click", () => {
        chips.forEach((c) => c.classList.remove("chip-active"));
        chip.classList.add("chip-active");
        statusFilter = chip.dataset.status;
        renderCameraList();
        plotCameras();
      });
    });
  }

  function visibleCameras() {
    return cameras.filter((c) => {
      if (statusFilter !== "all" && c.status !== statusFilter) return false;
      if (!searchTerm) return true;
      const hay = (c.code + " " + c.name + " " + (c.jurisdiction_path || "")).toLowerCase();
      return hay.includes(searchTerm);
    });
  }

  function renderCameraList() {
    const list = document.getElementById("camera-list");
    const rows = visibleCameras();
    list.innerHTML = "";
    if (!rows.length) {
      list.innerHTML = '<li class="empty-note">No cameras match.</li>';
      return;
    }
    for (const c of rows) {
      const li = document.createElement("li");
      li.className = "camera-row" + (c.camera_id === selectedCameraId ? " selected" : "");
      li.innerHTML =
        '<span class="dot" style="background:' + statusColor(c.status) + '"></span>' +
        '<span class="meta"><span class="code"></span><span class="name"></span></span>';
      li.querySelector(".code").textContent = c.code;
      li.querySelector(".name").textContent = c.name;
      li.addEventListener("click", () => selectCamera(c.camera_id, true));
      list.appendChild(li);
    }
  }

  // ---------------------------------------------------------------------
  // Map markers
  // ---------------------------------------------------------------------

  function plotCameras() {
    for (const { marker, wedge } of markers.values()) {
      map.removeLayer(marker);
      if (wedge) map.removeLayer(wedge);
    }
    markers.clear();

    const rows = visibleCameras();
    const bounds = [];
    for (const c of rows) {
      const pos = toPlane(c.location.lat, c.location.lon);
      bounds.push(pos);

      let wedge = null;
      const sector = sectorPolygon(pos, c.bearing_deg, c.fov_deg, c.range_m);
      if (sector) {
        wedge = L.polygon(sector, {
          color: statusColor(c.status),
          weight: 1,
          fillColor: statusColor(c.status),
          fillOpacity: 0.08,
          opacity: 0.35,
          interactive: false,
        }).addTo(map);
      }

      const marker = L.circleMarker(pos, {
        radius: 7,
        color: "#0a0e14",
        weight: 1.5,
        fillColor: statusColor(c.status),
        fillOpacity: 0.95,
      }).addTo(map);
      marker.bindPopup(popupHtml(c));
      marker.on("click", () => selectCamera(c.camera_id, false));

      markers.set(c.camera_id, { marker, wedge });
    }

    if (bounds.length) {
      map.fitBounds(L.latLngBounds(bounds).pad(0.25));
    }
  }

  function popupHtml(c) {
    return (
      '<div><b>' + escapeHtml(c.name) + '</b><br>' +
      '<span class="popup-code">' + escapeHtml(c.code) + "</span>" +
      '<div class="popup-row">' + escapeHtml(c.camera_type) + " &middot; " + escapeHtml(c.status) + "</div>" +
      '<div class="popup-row">' + escapeHtml(c.department || "") + "</div>" +
      "</div>"
    );
  }

  function selectCamera(cameraId, panMap) {
    selectedCameraId = cameraId;
    renderCameraList();
    const camera = cameras.find((c) => c.camera_id === cameraId);
    if (!camera) return;
    if (panMap) {
      const entry = markers.get(cameraId);
      if (entry) { map.panTo(entry.marker.getLatLng()); entry.marker.openPopup(); }
    }
    openDrawer(camera);
  }

  // ---------------------------------------------------------------------
  // Camera detail drawer
  // ---------------------------------------------------------------------

  function wireDrawer() {
    document.getElementById("cd-close").addEventListener("click", closeDrawer);
  }
  function openDrawer(c) {
    document.getElementById("cd-title").textContent = c.code;
    const body = document.getElementById("cd-body");
    body.innerHTML = "";
    const fields = [
      ["Name", c.name],
      ["Type", c.camera_type],
      ["Status", c.status],
      ["Department", c.department || "—"],
      ["Jurisdiction", c.jurisdiction_path || "—"],
      ["Location", c.location.lat.toFixed(5) + ", " + c.location.lon.toFixed(5)],
      ["Coverage", c.bearing_deg != null ? c.bearing_deg + "° bearing, " + c.fov_deg + "° FOV, " + c.range_m + "m range" : "—"],
    ];
    for (const [label, value] of fields) {
      const dt = document.createElement("dt"); dt.textContent = label;
      const dd = document.createElement("dd"); dd.textContent = value;
      body.appendChild(dt); body.appendChild(dd);
    }
    document.getElementById("camera-detail").hidden = false;
  }
  function closeDrawer() { document.getElementById("camera-detail").hidden = true; }

  // ---------------------------------------------------------------------
  // Tabs
  // ---------------------------------------------------------------------

  function wireTabs() {
    const tabs = document.querySelectorAll("#panel-tabs .tab");
    tabs.forEach((tab) => {
      tab.addEventListener("click", () => {
        tabs.forEach((t) => t.classList.remove("tab-active"));
        tab.classList.add("tab-active");
        document.querySelectorAll(".tab-body").forEach((b) => b.classList.remove("tab-body-active"));
        document.getElementById("tab-" + tab.dataset.tab).classList.add("tab-body-active");
      });
    });
  }

  // ---------------------------------------------------------------------
  // Live event feed + alerts
  // ---------------------------------------------------------------------

  const MAX_FEED_ITEMS = 80;

  function handleEvent(evt) {
    if (evt.kind === "track_start" && evt.track_id) liveTracks.add(evt.track_id);
    if (evt.kind === "track_end" && evt.track_id) liveTracks.delete(evt.track_id);

    const severity = severityOf(evt.kind);
    appendFeedItem("events-list", evt, severity);
    if (severity !== "routine") {
      appendFeedItem("alerts-list", evt, severity);
      openAlerts += 1;
      document.getElementById("alerts-count").textContent = String(openAlerts);
    }
    updateStats();
  }

  function appendFeedItem(listId, evt, severity) {
    const list = document.getElementById(listId);
    const empty = list.querySelector(".empty-note");
    if (empty) empty.remove();

    const camera = cameras.find((c) => c.camera_id === evt.camera_id);
    const li = document.createElement("li");
    li.className = "feed-item severity-" + severity;
    const time = new Date(evt.ts);
    li.innerHTML =
      '<div class="feed-head"><span class="feed-kind"></span><span class="feed-time"></span></div>' +
      '<div class="feed-cam"></div><div class="feed-detail"></div>';
    li.querySelector(".feed-kind").textContent = evt.kind;
    li.querySelector(".feed-time").textContent = time.toLocaleTimeString("en-GB");
    li.querySelector(".feed-cam").textContent =
      (camera ? camera.code : "camera " + evt.camera_id) + (evt.track_id ? " · " + evt.track_id : "");
    li.querySelector(".feed-detail").textContent = summarisePayload(evt);

    list.insertBefore(li, list.firstChild);
    while (list.children.length > MAX_FEED_ITEMS) list.removeChild(list.lastChild);
  }

  function summarisePayload(evt) {
    const p = evt.payload || {};
    switch (evt.kind) {
      case "anpr":
        return "plate " + (p.plate_text || "?") + " (conf " + fmtConf(p.confidence) + (p.format_valid === false ? ", format invalid" : "") + ")";
      case "track_start":
      case "track_update":
      case "track_end":
        return (p.class_label || "") + (p.confidence != null ? " conf " + fmtConf(p.confidence) : "") + (p.duration_seconds != null ? " · " + p.duration_seconds + "s" : "");
      case "dwell":
        return (p.class_label || "") + " dwelling " + (p.dwell_seconds || "?") + "s in " + (p.zone_id || "zone");
      case "proximity":
        return "sustained " + (p.seconds || "?") + "s at close range";
      case "stream_gap":
        return "camera unreachable for " + (p.gap_seconds || "?") + "s (" + (p.reason || "unknown") + ")";
      case "scene_change":
        return "scene discontinuity (" + (p.reason || "unknown") + ")";
      default:
        try { return JSON.stringify(p); } catch (e) { return ""; }
    }
  }
  function fmtConf(v) { return typeof v === "number" ? v.toFixed(2) : "?"; }

  // ---------------------------------------------------------------------
  // Stats
  // ---------------------------------------------------------------------

  function updateStats() {
    document.getElementById("stat-cameras").textContent = String(cameras.length);
    document.getElementById("stat-online").textContent = String(cameras.filter((c) => c.status === "active").length);
    document.getElementById("stat-tracks").textContent = String(liveTracks.size);
    document.getElementById("stat-alerts").textContent = String(openAlerts);
  }

  // ---------------------------------------------------------------------

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
})();
