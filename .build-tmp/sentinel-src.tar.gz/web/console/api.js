/* api.js — the console's only data-access layer.
 *
 * The registry service does not expose a camera or event API yet (as of this
 * writing it only has /api/health and /api/ready — see services/registry/app/main.py).
 * Rather than block the console on that, every function here tries the real,
 * same-origin endpoint first (the nginx config in web/nginx.conf proxies /api/ to
 * the registry, and CSP's connect-src 'self' means this console can only ever
 * call same-origin paths, never a third-party API) and falls back to a bundled,
 * clearly-labelled demo fixture when the endpoint is missing or unreachable.
 *
 * That fallback is not a placeholder to delete later: it is what lets this
 * console be evaluated and demoed today, and the switch to real data happens
 * automatically, with no code change here, the day someone adds
 *     GET  /api/cameras
 *     GET  /api/cameras/{id}/health
 *     GET  /api/events/stream        (Server-Sent Events; see connectEvents below)
 * to the registry. window.SentinelAPI.usingDemoData reports which mode is active
 * so app.js can show the DEMO/LIVE badge honestly.
 *
 * The demo event generator draws its vocabulary directly from
 * services/common/events.py (OBJECT_CLASSES, PLATED_CLASSES, PRIMITIVE_KINDS) so
 * that what you see here is shaped exactly like what the real edge worker
 * (services/analytics) actually emits, not an invented format.
 */
(function () {
  "use strict";

  const OBJECT_CLASSES = ["person", "bicycle", "motorcycle", "car", "auto_rickshaw", "bus", "truck", "tractor"];
  const PLATED_CLASSES = new Set(["motorcycle", "car", "auto_rickshaw", "bus", "truck", "tractor"]);

  // ---------------------------------------------------------------------
  // Demo camera fixture
  // ---------------------------------------------------------------------
  // Shaped after app.camera in db/migrations/002_camera.sql: code, name,
  // camera_type, status, location, bearing/fov/range wedge, department and
  // jurisdiction. Coordinates are real Ahmedabad locations; the cameras
  // themselves are fictional.

  const DEMO_CAMERAS = [
    cam(1, "AHM-NAV-0142", "Navrangpura Cross, Approach Rd", "anpr", "active",
      23.0339, 72.5622, 40, 90, 120, "Ahmedabad Traffic Police", "GJ.AHM.NAVRANGPURA"),
    cam(2, "AHM-NAV-0143", "Navrangpura Cross, Exit Rd", "anpr", "active",
      23.0341, 72.5628, 220, 90, 120, "Ahmedabad Traffic Police", "GJ.AHM.NAVRANGPURA"),
    cam(3, "AHM-ELS-0021", "Ellis Bridge, River Front", "ptz", "active",
      23.0258, 72.5714, 0, 360, 80, "Ahmedabad Municipal Corporation", "GJ.AHM.KHANPUR"),
    cam(4, "AHM-CGR-0087", "CG Road, Panchvati Junction", "fixed", "faulty",
      23.0195, 72.5561, 300, 100, 90, "Ahmedabad Traffic Police", "GJ.AHM.NAVRANGPURA"),
    cam(5, "AHM-MAN-0009", "Manek Chowk, East Gate", "dome", "active",
      23.0246, 72.5891, 150, 360, 60, "Ahmedabad Municipal Corporation", "GJ.AHM.KALUPUR"),
    cam(6, "AHM-SGH-0055", "SG Highway, Iskcon Overbridge", "anpr", "active",
      23.0284, 72.5069, 45, 80, 150, "Ahmedabad Traffic Police", "GJ.AHM.BODAKDEV"),
    cam(7, "AHM-SGH-0056", "SG Highway, Iskcon Underpass", "bullet", "maintenance",
      23.0281, 72.5075, 225, 80, 150, "Ahmedabad Traffic Police", "GJ.AHM.BODAKDEV"),
    cam(8, "AHM-VAS-0033", "Vastrapur Lake, North Path", "fixed", "active",
      23.0368, 72.5290, 90, 120, 70, "Ahmedabad Municipal Corporation", "GJ.AHM.VASTRAPUR"),
    cam(9, "AHM-RLY-0004", "Kalupur Railway Station, Gate 2", "thermal", "inactive",
      23.0272, 72.6013, 0, 360, 50, "Western Railway", "GJ.AHM.KALUPUR"),
    cam(10, "AHM-JUH-0018", "Juhapura Ring Road", "fixed", "active",
      22.9878, 72.5432, 10, 100, 100, "Ahmedabad Traffic Police", "GJ.AHM.JUHAPURA"),
  ];

  function cam(id, code, name, camera_type, status, lat, lon, bearing_deg, fov_deg, range_m, department, jurisdiction_path) {
    return {
      camera_id: id, code, name, camera_type, status,
      location: { lat, lon },
      bearing_deg, fov_deg, range_m,
      department, jurisdiction_path,
    };
  }

  // ---------------------------------------------------------------------
  // Cameras
  // ---------------------------------------------------------------------

  let usingDemoData = true;

  async function fetchCameras() {
    try {
      const res = await fetch("/api/cameras", { headers: { Accept: "application/json" } });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const data = await res.json();
      const cameras = Array.isArray(data) ? data : data.cameras || [];
      if (!cameras.length) throw new Error("empty response");
      usingDemoData = false;
      return cameras;
    } catch (err) {
      // Expected until the registry grows a /api/cameras endpoint. Not an error
      // an operator needs to see — the DEMO badge already says so.
      usingDemoData = true;
      return DEMO_CAMERAS;
    }
  }

  // ---------------------------------------------------------------------
  // Events — real stream if the registry ever serves one, else synthetic
  // ---------------------------------------------------------------------
  //
  // Real transport is Server-Sent Events on /api/events/stream, one JSON
  // PrimitiveEvent per "message" — SSE rather than a WebSocket because the
  // console only ever consumes events, never sends one back, and SSE
  // reconnects on its own without any code here having to implement that.

  function connectEvents(cameras, onEvent) {
    if (typeof EventSource !== "undefined") {
      try {
        const source = new EventSource("/api/events/stream");
        let receivedAny = false;
        const fallbackTimer = setTimeout(() => {
          if (!receivedAny) {
            source.close();
            startSyntheticFeed(cameras, onEvent);
          }
        }, 2500);
        source.onmessage = (msg) => {
          receivedAny = true;
          clearTimeout(fallbackTimer);
          usingDemoData = false;
          try { onEvent(JSON.parse(msg.data)); } catch (e) { /* malformed line, skip */ }
        };
        source.onerror = () => {
          if (!receivedAny) {
            clearTimeout(fallbackTimer);
            source.close();
            startSyntheticFeed(cameras, onEvent);
          }
        };
        return;
      } catch (err) {
        // fall through to synthetic
      }
    }
    startSyntheticFeed(cameras, onEvent);
  }

  function startSyntheticFeed(cameras, onEvent) {
    usingDemoData = true;
    const sim = new EventSimulator(cameras, onEvent);
    sim.start();
  }

  /** Drives a plausible stream of PrimitiveEvent-shaped objects per camera. */
  class EventSimulator {
    constructor(cameras, onEvent) {
      this.cameras = cameras.filter((c) => c.status === "active");
      this.onEvent = onEvent;
      this.tracksByCamera = new Map();
      this.seq = 1;
    }

    start() {
      if (!this.cameras.length) return;
      this.timer = setInterval(() => this.tick(), 1100);
      // A little immediate activity so the panel isn't empty on load.
      for (let i = 0; i < 4; i++) this.tick();
    }

    stop() {
      clearInterval(this.timer);
    }

    tick() {
      const now = new Date().toISOString();
      for (const camera of this.cameras) {
        let tracks = this.tracksByCamera.get(camera.camera_id);
        if (!tracks) {
          tracks = [];
          this.tracksByCamera.set(camera.camera_id, tracks);
        }

        // End tracks whose lifetime has expired.
        for (let i = tracks.length - 1; i >= 0; i--) {
          const t = tracks[i];
          if (Date.now() > t.endsAt) {
            this.emit(camera, "track_end", t.trackId, {
              class_label: t.classLabel,
              reason: "lost",
              duration_seconds: Math.round((Date.now() - t.startedAt) / 100) / 10,
            });
            tracks.splice(i, 1);
          }
        }

        // Occasionally start a new track.
        if (tracks.length < 3 && Math.random() < 0.35) {
          const classLabel = OBJECT_CLASSES[Math.floor(Math.random() * OBJECT_CLASSES.length)];
          const trackId = "c" + camera.camera_id + "-sim-" + this.seq++;
          const track = {
            trackId,
            classLabel,
            startedAt: Date.now(),
            endsAt: Date.now() + 4000 + Math.random() * 12000,
            platedRead: false,
            bbox: randomBBox(),
          };
          tracks.push(track);
          this.emit(camera, "track_start", trackId, {
            class_label: classLabel,
            confidence: round(0.55 + Math.random() * 0.4),
            bbox: track.bbox,
          });
        }

        // Heartbeat + occasional ANPR / dwell / proximity for live tracks.
        for (const t of tracks) {
          if (Math.random() < 0.6) {
            this.emit(camera, "track_update", t.trackId, {
              class_label: t.classLabel,
              confidence: round(0.5 + Math.random() * 0.45),
              bbox: (t.bbox = jitterBBox(t.bbox)),
              age_seconds: round((Date.now() - t.startedAt) / 1000),
            });
          }
          if (!t.platedRead && PLATED_CLASSES.has(t.classLabel) && Math.random() < 0.18) {
            t.platedRead = true;
            this.emit(camera, "anpr", t.trackId, {
              plate_text: randomPlate(),
              confidence: round(0.7 + Math.random() * 0.28),
              format_valid: Math.random() > 0.12,
              engine: "stub",
            });
          }
          if (Math.random() < 0.02) {
            this.emit(camera, "dwell", t.trackId, {
              zone_id: "zone-demo",
              class_label: t.classLabel,
              dwell_seconds: round(10 + Math.random() * 40),
              still: Math.random() > 0.5,
            });
          }
        }

        if (tracks.length >= 2 && Math.random() < 0.015) {
          const [a, b] = tracks;
          this.emit(camera, "proximity", a.trackId, {
            track_ids: [a.trackId, b.trackId],
            class_labels: [a.classLabel, b.classLabel],
            seconds: round(6 + Math.random() * 10),
            distance_unit: "normalised",
          });
        }

        if (Math.random() < 0.003) {
          this.emit(camera, "stream_gap", null, {
            reason: "stalled",
            gap_seconds: round(5 + Math.random() * 20),
          });
        }
      }
    }

    emit(camera, kind, trackId, payload) {
      this.onEvent({
        kind,
        camera_id: camera.camera_id,
        camera_code: camera.code,
        ts: new Date().toISOString(),
        track_id: trackId,
        payload,
      });
    }
  }

  function randomBBox() {
    const x1 = round(Math.random() * 0.7);
    const y1 = round(0.3 + Math.random() * 0.4);
    return [x1, y1, round(x1 + 0.1 + Math.random() * 0.15), round(y1 + 0.08 + Math.random() * 0.1)];
  }
  function jitterBBox(b) {
    const dx = (Math.random() - 0.5) * 0.03;
    return [round(clamp01(b[0] + dx)), b[1], round(clamp01(b[2] + dx)), b[3]];
  }
  function clamp01(v) { return Math.max(0, Math.min(1, v)); }
  function round(v) { return Math.round(v * 1000) / 1000; }

  const PLATE_LETTERS = ["AB", "CD", "GH", "JK", "MN", "PQ", "XY"];
  function randomPlate() {
    const district = String(1 + Math.floor(Math.random() * 38)).padStart(2, "0");
    const letters = PLATE_LETTERS[Math.floor(Math.random() * PLATE_LETTERS.length)];
    const number = String(Math.floor(Math.random() * 10000)).padStart(4, "0");
    return `GJ${district}${letters}${number}`;
  }

  // ---------------------------------------------------------------------

  window.SentinelAPI = {
    fetchCameras,
    connectEvents,
    get usingDemoData() { return usingDemoData; },
  };
})();
