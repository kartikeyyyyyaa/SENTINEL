"""Worker entrypoint. One process per N cameras, one thread per camera.

**Why not one process per camera.** Fifty processes each holding their own copy of
a detector session is fifty copies of the weights and fifty interpreter heaps. On
hardware a district can actually afford, that is the difference between running
and not running. So: one process, several camera threads, one shared detector and
one shared OCR reader.

**Why threads work despite the GIL.** Almost all of the wall time in a camera
thread is spent inside code that releases the GIL — the FFmpeg decode via OpenCV,
the numpy frame differencing, the ONNX/torch/Paddle inference. The Python-level
work between those calls is small. Threads are also the only option that lets
several cameras share one model instance, which is the memory saving above.

**Why inference is serialised behind a lock.** Ultralytics and PaddleOCR sessions
are not safe to call concurrently from several threads, and even if they were,
oversubscribing one CPU with eight simultaneous inferences is slower in aggregate
than running them one at a time — the same work, plus cache thrash and scheduler
churn. ``SerialisedDetector`` / ``SerialisedReader`` make that explicit rather than
accidental. What it costs is queueing, and queueing is exactly what the adaptive
sampler (inside each camera's own ``source.FrameSource``) measures and responds to
by widening that camera's stride.

**What owns what.** Each camera gets its own ``Cascade`` (motion, detect, plate,
ocr and the tracker — see ``cascade.py``) and its own ``PrimitiveEngine`` (zones,
lines, speed, crowd, abandoned, proximity — see ``primitives.py``), because both
hold per-camera state that a scene-change reset must clear without disturbing any
other camera. Frame capture, PTS-derived timing and adaptive frame shedding all
live inside the camera's ``source.FrameSource`` already and are not duplicated
here; this module's job is to drive that generator, run each accepted frame
through the cascade and the primitive engine, and hand the resulting events to the
sink.

**Run modes.**

    python -m services.analytics.main                 # config from environment
    python -m services.analytics.main --dry-run        # synthetic frames, stub models, no network
    python -m services.analytics.main --self-test      # dry run plus assertions on the cascade

``--dry-run`` and ``--self-test`` need no GPU, no model weights and no route to the
sandbox, which is what makes the pipeline testable on a development machine and in
CI. The measured numbers they print are computed by exactly the same ``Cascade``
and ``PrimitiveEngine`` code as the live path, so the two are comparable.
"""
from __future__ import annotations

import argparse
import json
import logging
import signal
import sys
import threading
import time
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from typing import Any

from services.common.events import PrimitiveEvent

from .cascade import Cascade, CascadeStats
from .config import CameraConfig, WorkerConfig, resolve_config
from .primitives import PrimitiveEngine
from .sink import BufferedEventSink, MemoryTransport, build_sink
from .source import Frame, FrameSource, SyntheticSource, build_source
from .stages.detect import Detector, StubDetector, build_detector, validate_class_map
from .stages.plate import OcrReader, StubOcrReader, build_reader

log = logging.getLogger("services.analytics.main")


class SerialisedDetector:
    """One model, one caller at a time. See the module docstring.

    Also records queueing time, separately from inference time. Without that
    split, a worker that is oversubscribed looks identical in the stage timings to
    one whose model is slow, and the two call for opposite responses: fewer
    cameras per process versus a smaller model.
    """

    def __init__(self, inner: Detector) -> None:
        self._inner = inner
        self._lock = threading.Lock()
        self.name = f"serialised:{getattr(inner, 'name', type(inner).__name__)}"
        self.wait_seconds = 0.0

    def detect(self, frame: Any, frame_index: int = 0) -> list:
        t0 = time.perf_counter()
        with self._lock:
            self.wait_seconds += time.perf_counter() - t0
            return self._inner.detect(frame, frame_index)


class SerialisedReader:
    """Same argument as ``SerialisedDetector``, for the OCR engine.

    ``calls`` is delegated rather than re-derived, because ``cascade.Cascade``
    reads it straight off ``PlateReadStage.reader`` to count real inferences for
    the funnel report — see ``cascade._reader_calls``. A wrapper that did not
    expose it would make every camera's OCR cost look unpriced.
    """

    def __init__(self, inner: OcrReader) -> None:
        self._inner = inner
        self._lock = threading.Lock()
        self.name = f"serialised:{getattr(inner, 'name', type(inner).__name__)}"
        self.wait_seconds = 0.0
        self.calls = 0

    def read(self, image: Any) -> tuple[str, float]:
        t0 = time.perf_counter()
        with self._lock:
            self.wait_seconds += time.perf_counter() - t0
            self.calls += 1
            return self._inner.read(image)


@dataclass
class CameraWorker:
    """Drives one camera: capture, cascade, primitives, emit.

    Every exception is caught and logged rather than propagated. One camera with a
    broken stream must not take down the other seven in the process, and on a
    fifty-camera live test at least one camera will be broken.
    """

    camera: CameraConfig
    config: WorkerConfig
    cascade: Cascade
    primitives: PrimitiveEngine
    sink: BufferedEventSink
    stop: threading.Event

    def run(self) -> None:
        source = build_source(self.camera, self.config.source, self.config.sampling)
        log.info(
            "camera %s starting (%s)", self.camera.camera_id, type(source).__name__
        )
        watchdog = threading.Thread(
            target=self._watch_stall,
            args=(source,),
            name=f"cam-{self.camera.camera_id}-watchdog",
            daemon=True,
        )
        watchdog.start()
        try:
            for frame in source.frames():
                if self.stop.is_set():
                    break
                self._handle_frame(frame)
        except Exception as exc:  # noqa: BLE001 - one camera, not the process
            log.exception("camera %s thread failed: %s", self.camera.camera_id, exc)
        finally:
            source.close()
            watchdog.join(timeout=5.0)
            log.info("camera %s stopped", self.camera.camera_id)

    def _handle_frame(self, frame: Frame) -> None:
        timing = frame.timing
        events: list[PrimitiveEvent] = []

        if frame.gap_seconds is not None:
            # The worker was not watching for this many seconds of wall clock: a
            # reconnect, not a scene event. See Frame.gap_seconds's docstring —
            # "the camera saw nothing" and "the worker was not watching" are
            # different facts and a rule reasoning about a missed exit needs both.
            events.append(self._gap_event(timing.ts, frame.gap_seconds, "reconnect"))

        if timing.discontinuity:
            # The sandbox feed looped, or we reconnected at a different point in
            # it. Reset the cascade (motion reference, tracker, OCR dedupe) and the
            # primitive engine (zone/line/pair state) together, in that order,
            # before this frame is processed against either.
            events.extend(self.cascade.reset_scene(timing.pts, timing.ts))
            self.primitives.reset()

        try:
            outcome = self.cascade.process(
                frame.image,
                t=timing.pts,
                ts=timing.ts,
                pts=timing.pts,
                frame_index=timing.frame_index,
            )
        except Exception as exc:  # noqa: BLE001 - one frame, not the camera
            log.exception("camera %s frame failed: %s", self.camera.camera_id, exc)
            if events:
                self.sink.emit_many(events)
            return

        events.extend(outcome.events)
        if outcome.analysed:
            # Primitives only see frames the cascade actually looked at. A frame
            # the motion gate dropped produced no tracks to reason about, and
            # feeding it an empty track list would just churn the pair-state
            # bookkeeping for zero benefit.
            events.extend(self.primitives.update(outcome.tracks, timing.pts, timing.ts))

        if events:
            self.sink.emit_many(events)
        self.sink.flush()

    def _watch_stall(self, source: FrameSource) -> None:
        """Poll for a stalled stream from outside the (blocking) frame loop.

        ``frames()`` is blocked inside a socket read while stalled and cannot
        notice its own silence; only a second observer can. See
        ``source.RtspSource.stall``'s docstring. ``SyntheticSource`` has no
        ``stall`` attribute, and this simply has nothing to do for one.
        """
        stall = getattr(source, "stall", None)
        if stall is None:
            return
        while not self.stop.is_set():
            duration = stall.check(time.monotonic())
            if duration is not None:
                self.sink.emit(
                    self._gap_event(datetime.now(timezone.utc), duration, "stalled")
                )
            if self.stop.wait(2.0):
                break

    def _gap_event(self, ts: datetime, seconds: float, reason: str) -> PrimitiveEvent:
        return PrimitiveEvent(
            kind="stream_gap",
            camera_id=self.camera.camera_id,
            ts=ts,
            payload={"reason": reason, "gap_seconds": round(seconds, 2)},
        )


class Worker:
    """A process's worth of cameras."""

    def __init__(self, config: WorkerConfig) -> None:
        config.validate()
        self.config = config
        self.stop = threading.Event()
        self.sink = build_sink(config.sink)
        # Built once per process and shared. This is the whole reason the worker
        # is threaded rather than forked; see the module docstring.
        self.detector: Detector = SerialisedDetector(build_detector(config.detect))
        self.reader: OcrReader = SerialisedReader(build_reader(config.ocr))
        self.cascades: dict[int, Cascade] = {}
        self.workers: list[CameraWorker] = []
        self.threads: list[threading.Thread] = []

    def install_signal_handlers(self) -> None:
        def handle(signum: int, _frame: Any) -> None:
            log.info("signal %s received, stopping", signum)
            self.stop.set()

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, handle)
            except (ValueError, OSError):  # pragma: no cover - not the main thread
                pass

    def start(self) -> None:
        if not self.config.cameras:
            raise SystemExit(
                "no cameras configured. Set ANALYTICS_CAMERAS to a comma-separated "
                "list of camera_id=url pairs, or pass --cameras, or use --dry-run."
            )
        for camera in self.config.cameras:
            cascade = Cascade(
                camera.camera_id, self.config, detector=self.detector, reader=self.reader
            )
            self.cascades[camera.camera_id] = cascade
            worker = CameraWorker(
                camera=camera,
                config=self.config,
                cascade=cascade,
                primitives=PrimitiveEngine(camera, self.config.primitives),
                sink=self.sink,
                stop=self.stop,
            )
            self.workers.append(worker)
            thread = threading.Thread(
                target=worker.run, name=f"cam-{camera.camera_id}", daemon=True
            )
            self.threads.append(thread)
            thread.start()

    def run(self) -> dict[str, Any]:
        self.start()
        deadline = (
            time.monotonic() + self.config.run_seconds
            if self.config.run_seconds > 0
            else None
        )
        next_report = time.monotonic() + self.config.stats_interval_seconds
        try:
            while not self.stop.is_set():
                if deadline is not None and time.monotonic() >= deadline:
                    log.info("run duration reached, stopping")
                    break
                if not any(t.is_alive() for t in self.threads):
                    break
                if time.monotonic() >= next_report:
                    next_report = time.monotonic() + self.config.stats_interval_seconds
                    self.report()
                self.sink.flush()
                self.stop.wait(0.25)
        finally:
            self.stop.set()
            for thread in self.threads:
                thread.join(timeout=10.0)
            report = self.report()
            self.sink.close()
        return report

    def report(self) -> dict[str, Any]:
        """Log and return the measured cascade numbers, fleet-wide and per camera.

        Reported on a timer rather than only at shutdown. A worker killed when the
        demo ends must still have reported the figures the submission needs, and
        "we had them but the process was SIGKILLed" is not a recoverable position.
        """
        fleet = CascadeStats()
        per_camera: list[dict[str, Any]] = []
        tracker_totals = {
            "tracks_started": 0,
            "tracks_ended": 0,
            "id_switches_prevented": 0,
            "scene_resets": 0,
        }
        for camera_id, cascade in self.cascades.items():
            fleet.merge(cascade.stats)
            snapshot = cascade.stats.as_dict()
            snapshot["camera_id"] = camera_id
            per_camera.append(snapshot)
            tracker = cascade.tracker
            tracker_totals["tracks_started"] += tracker.tracks_started
            tracker_totals["tracks_ended"] += tracker.tracks_ended
            tracker_totals["id_switches_prevented"] += tracker.id_switches_prevented
            tracker_totals["scene_resets"] += tracker.scene_resets

        report = fleet.as_dict()
        report["cameras"] = len(self.cascades)
        report["tracker"] = tracker_totals
        report["sink"] = self.sink.stats.as_dict()
        report["model_queueing_seconds"] = {
            "detector": round(getattr(self.detector, "wait_seconds", 0.0), 3),
            "reader": round(getattr(self.reader, "wait_seconds", 0.0), 3),
        }
        report["per_camera"] = per_camera
        log.info("cascade report: %s", json.dumps(report, separators=(",", ":"), default=str))
        return report


def dry_run_config(cameras: int = 2) -> WorkerConfig:
    """A no-network, no-weights configuration.

    Two cameras rather than one, so the shared-model lock and the shared sink are
    both actually exercised — a single-camera dry run would pass with a detector
    that is not thread-safe and a sink that is not, and never notice.
    """
    config = WorkerConfig(
        worker_id="dry-run",
        cameras=tuple(
            CameraConfig(camera_id=i, url="stub://", stub=True) for i in range(1, cameras + 1)
        ),
        stats_interval_seconds=1e9,  # Report once, at the end.
    )
    config.validate()
    return config


def run_dry(frames: int = 240) -> dict[str, Any]:
    """Drive the real cascade and primitive engine over synthetic frames.

    Single-threaded and synchronous on purpose: this is the path the self-test and
    the unit tests use, and a deterministic frame count with no thread scheduling
    makes the reported reduction factors reproducible. Reproducibility matters
    because these numbers go into a submission. Events go to an in-memory
    transport rather than stdout, so running this from a test suite does not spam
    the test runner's output.
    """
    config = dry_run_config()
    detector = StubDetector(config.detect)
    reader = StubOcrReader()  # takes an optional confidence float, not an OcrConfig
    sink = BufferedEventSink(MemoryTransport(), config.sink)

    fleet = CascadeStats()
    per_camera: list[dict[str, Any]] = []
    tracker_totals = {
        "tracks_started": 0,
        "tracks_ended": 0,
        "id_switches_prevented": 0,
        "scene_resets": 0,
    }
    for camera in config.cameras:
        cascade = Cascade(camera.camera_id, config, detector=detector, reader=reader)
        primitives = PrimitiveEngine(camera, config.primitives)
        source = SyntheticSource(
            camera.camera_id,
            total_frames=frames,
            loop_frames=frames // 2,  # Exercise the loop cut and the tracker reset.
            source_config=config.source,
            sampling=config.sampling,
        )
        for frame in source.frames():
            timing = frame.timing
            events: list[PrimitiveEvent] = []
            if timing.discontinuity:
                events.extend(cascade.reset_scene(timing.pts, timing.ts))
                primitives.reset()
            outcome = cascade.process(
                frame.image,
                t=timing.pts,
                ts=timing.ts,
                pts=timing.pts,
                frame_index=timing.frame_index,
            )
            events.extend(outcome.events)
            if outcome.analysed:
                events.extend(primitives.update(outcome.tracks, timing.pts, timing.ts))
            sink.emit_many(events)
        fleet.merge(cascade.stats)
        snapshot = cascade.stats.as_dict()
        snapshot["camera_id"] = camera.camera_id
        per_camera.append(snapshot)
        tracker = cascade.tracker
        tracker_totals["tracks_started"] += tracker.tracks_started
        tracker_totals["tracks_ended"] += tracker.tracks_ended
        tracker_totals["id_switches_prevented"] += tracker.id_switches_prevented
        tracker_totals["scene_resets"] += tracker.scene_resets

    sink.flush(force=True)
    report = fleet.as_dict()
    report["cameras"] = len(config.cameras)
    report["tracker"] = tracker_totals
    report["sink"] = sink.stats.as_dict()
    report["per_camera"] = per_camera
    return report


def self_test(frames: int = 240) -> int:
    """Dry run plus the assertions that matter. Returns a process exit code.

    Checks the *structural* properties that would invalidate the submission's
    numbers if they silently stopped holding: that the cascade actually narrows,
    and that OCR is doing real, bounded work rather than none or all of it. Those
    are deterministic given a fixed synthetic input and a fixed configuration, so
    a failure here means the pipeline itself is wrong.

    ``effective_speedup`` is printed but deliberately not asserted on. It is a
    wall-clock measurement, and on this dry run every backend is a stub costing
    microseconds — the "hypothetical" and "measured" totals it divides are both
    dominated by scheduler jitter and CPU frequency scaling rather than by any
    real per-unit model cost, so the ratio can land on either side of 1.0 between
    two runs on the same unchanged code. That noise is a property of measuring
    real time with fake, near-zero-cost work, not a regression; the number means
    something once the detector and OCR backends are the real ones, and this
    dry run's cascade-narrowing checks below cover the property that must always
    hold regardless of backend speed.
    """
    validate_class_map()
    report = run_dry(frames)
    print(json.dumps(report, indent=2, default=str))

    problems: list[str] = []
    funnel = report["funnel"]
    stages = {s["name"]: s for s in funnel["stages"]}

    if funnel["frames_offered"] <= 0:
        problems.append("no frames were offered")
    if funnel["frames_analysed"] <= 0:
        problems.append("the motion gate passed nothing; the cascade never started")

    if "ocr" in stages:
        ocr = stages["ocr"]
        if ocr["cumulative_ratio"] >= 1.0:
            problems.append("ocr ran on every frame: the cascade is not narrowing")
        if ocr["items_out"] <= 0:
            problems.append("ocr never produced a read on the dry run; nothing was exercised")

    for problem in problems:
        print(f"FAIL: {problem}", file=sys.stderr)
    return 1 if problems else 0


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="services.analytics.main",
        description="Sentinel edge analytics worker. Consumes RTSP, emits metadata.",
    )
    parser.add_argument(
        "--cameras",
        default="",
        help="comma-separated camera_id=rtsp://... pairs, overriding ANALYTICS_CAMERAS",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="synthetic frames and stub models; no network, no weights, no GPU",
    )
    parser.add_argument(
        "--self-test",
        action="store_true",
        help="dry run, then assert the cascade actually narrows; exits non-zero if not",
    )
    parser.add_argument("--frames", type=int, default=240, help="frames per dry-run camera")
    parser.add_argument(
        "--duration", type=float, default=0.0, help="stop after this many seconds (0 = forever)"
    )
    parser.add_argument(
        "--shard",
        type=int,
        default=-1,
        help="run only shard N of the camera list, split by max_cameras_per_process",
    )
    parser.add_argument("--stats-json", default="", help="write the final report to this path")
    parser.add_argument("--log-level", default="", help="override LOG_LEVEL")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)

    if args.self_test:
        # No env, no network: matches --dry-run's isolation. Logging is not set up
        # yet at this point on purpose, so a self-test run's only output is the
        # JSON report and any FAIL lines.
        return self_test(args.frames)

    config = resolve_config(args.cameras)
    logging.basicConfig(
        level=(args.log_level or config.log_level).upper(),
        format="%(asctime)s %(levelname)s %(name)s %(threadName)s %(message)s",
        # stderr, so that stdout stays a clean JSONL event stream when the sink is
        # unconfigured and something downstream is piping it.
        stream=sys.stderr,
    )

    if args.dry_run:
        report = run_dry(args.frames)
        print(json.dumps(report, indent=2, default=str))
        _write_report(args.stats_json, report)
        return 0

    if args.duration > 0:
        config = replace(config, run_seconds=args.duration)
    if args.shard >= 0:
        shards = config.shards()
        if args.shard >= len(shards):
            raise SystemExit(f"shard {args.shard} out of range: {len(shards)} shard(s)")
        config = config.with_cameras(shards[args.shard])
        log.info(
            "running shard %d of %d: %d camera(s)",
            args.shard, len(shards), len(config.cameras),
        )

    worker = Worker(config)
    worker.install_signal_handlers()
    report = worker.run()
    _write_report(args.stats_json, report)
    return 0


def _write_report(path: str, report: dict[str, Any]) -> None:
    if not path:
        return
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2, default=str)
    log.info("wrote cascade report to %s", path)


if __name__ == "__main__":
    raise SystemExit(main())
